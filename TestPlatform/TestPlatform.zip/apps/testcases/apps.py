from django.apps import AppConfig


class TestcasesConfig(AppConfig):
    name = 'testcases'
