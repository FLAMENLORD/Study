from django.apps import AppConfig


class TestsuitesConfig(AppConfig):
    name = 'testsuits'
