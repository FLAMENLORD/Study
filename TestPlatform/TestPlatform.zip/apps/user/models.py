from django.db import models

from utils.base_model import BaseModel

