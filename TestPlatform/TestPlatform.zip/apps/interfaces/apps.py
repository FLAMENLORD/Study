from django.apps import AppConfig


class InterfacesConfig(AppConfig):
    name = 'interfaces'
