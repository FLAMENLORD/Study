from django.apps import AppConfig


class DebugtalksConfig(AppConfig):
    name = 'debugtalks'
