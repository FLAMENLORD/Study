from django.apps import AppConfig


class EnvsConfig(AppConfig):
    name = 'envs'
