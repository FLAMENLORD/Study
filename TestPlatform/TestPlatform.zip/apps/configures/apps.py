from django.apps import AppConfig


class ConfiguresConfig(AppConfig):
    name = 'configures'
