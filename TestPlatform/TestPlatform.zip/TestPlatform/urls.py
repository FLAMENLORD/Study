# -*-coding:utf-8-*-
from django.conf.urls import url, static
from django.urls import path, include, re_path
from rest_framework.documentation import include_docs_urls
from drf_yasg import openapi
from drf_yasg.views import get_schema_view

from TestPlatform import settings
from . import views

# 声明schema_view
schema_view = get_schema_view(
    openapi.Info(
        title="Lemon API接口文档平台",
        default_version='v1',
        description="Lemon接口自动化平台项目API文档",
        terms_of_service="http://api.keyou.site",
        contact=openapi.Contact(email="keyou100@qq.com"),
        license=openapi.License(name="BSD License"),
    ),
    public=True,
)

urlpatterns = [
    # 寻找静态文件目录
    url(r'^static/(?P<path>.*)$', static.serve,{'document_root': settings.STATIC_ROOT}, name='static'),
    path('', include('projects.urls')),
    path('', include('interfaces.urls')),
    path('', include('envs.urls')),
    path('', include('testcases.urls')),
    path('', include('testsuits.urls')),
    path('', include('configures.urls')),
    path('', include('debugtalks.urls')),
    path('', include('reports.urls')),
    path('docs/', include_docs_urls(title='测试平台接口文档')),
    re_path(r'^swagger(?P<format>\.json|\.yaml)$', schema_view.without_ui(cache_timeout=0), name='schema-json'),
    path('swagger/', schema_view.with_ui('swagger', cache_timeout=0), name='schema-swagger-ui'),
    # path('redoc/', schema_view.with_ui('redoc', cache_timeout=0), name='schema-redoc'),
    path('user/', include('user.urls')),
    path('summary/', views.SummaryView.as_view()),

]
