
from rest_framework.views import APIView, Response
from django.db.models import Sum
from datetime import datetime

from projects.models import Projects
from interfaces.models import Interfaces
from testsuits.models import Testsuits
from testcases.models import Testcases
from configures.models import Configures
from debugtalks.models import DebugTalks
from envs.models import Envs
from reports.models import Reports


class SummaryView(APIView):
    def get(self, request):
	    fail_count = Reports.objects.filter(success=0).count()
	    count = Reports.objects.aggregate(count=Sum('count'))['count']
	    fail_rate = int(fail_count/count*100)

	    user = {
		    'user': {
			    'date_joined':  request.user.date_joined.strftime('%Y-%m-%d %H:%M:%S'),
			    'last_login': request.user.last_login.strftime('%Y-%m-%d %H:%M:%S') if  request.user.last_login else '',
			    'role': '管理员' if request.user.is_superuser else '普通用户',
			    'username': request.user.username
		    },
		    'statistics': {
			    'configures_count': Configures.objects.all().count(),
			    'debug_talks_count': DebugTalks.objects.all().count(),
			    'envs_count': Envs.objects.all().count(),
			    'fail_rate': fail_rate,
			    'interfaces_count': Interfaces.objects.all().count(),
			    'projects_count': Projects.objects.all().count(),
			    'reports_count': Reports.objects.all().count(),
			    'success_rate': 100-fail_rate,
			    'testcases_count': Testcases.objects.all().count(),
			    'testsuits_count': Testsuits.objects.all().count(),
		    },
	    }
	    
	    request.user.last_login = str(datetime.today())
	    request.user.save()
	    return Response(user)
